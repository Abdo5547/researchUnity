import React from "react";
import Ques from "./Ques";
import AfficherQuestion from "../Afficher/QuestionInterest";

function SetQuestion() {
  return (
    <div>
      <Ques />
    </div>
  );
}

export default SetQuestion;
